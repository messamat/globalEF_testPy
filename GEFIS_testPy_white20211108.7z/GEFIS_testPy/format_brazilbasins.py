#Download SNIRH_RegioesHidrograficas_2020.zip from https://metadados.snirh.gov.br/geonetwork/srv/api/records/0574947a-2c5b-48d2-96a4-b07c4702bbab
#to determine location of hydrographic regions